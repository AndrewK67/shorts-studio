import { NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';

// ============================================
// ANTHROPIC CLIENT SETUP
// ============================================

const apiKey = process.env.ANTHROPIC_API_KEY;
if (!apiKey) {
  console.error('[ERROR] ANTHROPIC_API_KEY is not set in environment variables');
}

const anthropic = new Anthropic({
  apiKey: apiKey || '',
});

// ============================================
// TYPES
// ============================================

interface TopicGenerationRequest {
  projectName: string;
  month: string;
  videosNeeded: number;
  toneMix: {
    emotional: number;
    calming: number;
    storytelling: number;
    educational: number;
    humor: number;
  };
  profile: {
    niche: string;
    uniqueAngle: string;
    signatureTone: {
      primary: string;
      secondary: string;
      accent: string;
    };
    catchphrases: string[];
    boundaries: {
      wontCover: string[];
      privacyLimits: string[];
    };
  };
  regional: {
    location: string;
    countryCode: string;
    hemisphere: string;
    timezone: string;
    language: string;
    holidays: Array<{
      date: string;
      name: string;
      culturalContext: string;
    }>;
  };
  customEvents: Array<{
    date: string;
    name: string;
    type: string;
    priority: string;
  }>;
  existingTopics: string[];
  productionMode: 'traditional' | 'ai-voice' | 'fully-ai';
}

// ============================================
// PROMPT BUILDER
// ============================================

function buildTopicGenerationPrompt(request: TopicGenerationRequest): string {
  const {
    projectName,
    month,
    videosNeeded,
    toneMix,
    profile,
    regional,
    customEvents,
    existingTopics,
    productionMode,
  } = request;

  const monthDate = new Date(month);
  const monthName = monthDate.toLocaleString('en-GB', { month: 'long' });
  const year = monthDate.getFullYear();
  
  const monthHolidays = regional.holidays.filter(h => {
    const holidayDate = new Date(h.date);
    return holidayDate.getMonth() === monthDate.getMonth() &&
           holidayDate.getFullYear() === year;
  });

  let productionContext = '';
  if (productionMode === 'traditional') {
    productionContext = 'User will film themselves. Suggest topics for authentic, personal delivery.';
  } else if (productionMode === 'ai-voice') {
    productionContext = 'User will use AI voiceover with stock footage. Topics should be visual.';
  } else {
    productionContext = 'User will create fully AI-generated videos. Topics should be visually creative.';
  }

  const prompt = `You are an expert YouTube Shorts content strategist for ${monthName} ${year}.

CREATOR: ${profile.niche} | ${profile.uniqueAngle}
TONE: ${profile.signatureTone.primary} (${profile.signatureTone.secondary}, ${profile.signatureTone.accent})
LOCATION: ${regional.countryCode} | ${regional.language}

IMPORTANT: Use ${regional.language} spelling. Reference ${regional.countryCode} holidays, NOT American ones.

KEY DATES: ${monthHolidays.map(h => h.name).join(', ') || 'None'}
PRODUCTION: ${productionContext}

TONE MIX: ${toneMix.emotional}% emotional, ${toneMix.calming}% calming, ${toneMix.storytelling}% story, ${toneMix.educational}% educational, ${toneMix.humor}% humor

Generate exactly ${videosNeeded} YouTube Shorts topics as JSON ONLY (no markdown):

{
  "topics": [
    {
      "title": "clear, specific title (50-80 chars)",
      "hook": "attention-grabbing first 3 seconds",
      "coreValue": "what viewer gains",
      "emotionalDriver": "why they'll share",
      "formatType": "Story|List|Tutorial|etc",
      "tone": "matches tone mix",
      "longevity": "evergreen|seasonal|trending",
      "factCheckStatus": "verified|needs_review|opinion",
      "dateRangeStart": "YYYY-MM-DD",
      "dateRangeEnd": "YYYY-MM-DD",
      "productionNotes": "tips for ${productionMode}"
    }
  ]
}`;

  return prompt;
}

// ============================================
// STREAMING API HANDLER
// ============================================

export async function POST(request: Request) {
  console.log('[TOPICS API STREAM] Starting streaming topic generation...');
  
  try {
    const body: TopicGenerationRequest = await request.json();
    console.log('[TOPICS API STREAM] Received request:', {
      projectName: body.projectName,
      month: body.month,
      videosNeeded: body.videosNeeded,
      productionMode: body.productionMode,
      country: body.regional?.countryCode,
    });

    // Validate
    if (!body.projectName || !body.month || !body.videosNeeded) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    if (!body.profile || !body.regional) {
      return NextResponse.json(
        { error: 'Missing profile or regional data' },
        { status: 400 }
      );
    }

    if (!apiKey) {
      return NextResponse.json(
        { error: 'AI service not configured' },
        { status: 500 }
      );
    }

    const prompt = buildTopicGenerationPrompt(body);
    console.log('[TOPICS API STREAM] Calling Anthropic API with streaming...');

    // Create streaming response
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // Call Anthropic with streaming enabled
          const anthropicStream = await anthropic.messages.create({
            model: 'claude-sonnet-4-20250514',
            max_tokens: 8000,
            temperature: 0.7,
            stream: true,
            messages: [
              {
                role: 'user',
                content: prompt,
              },
            ],
          });

          let fullResponse = '';
          let lastProgressUpdate = Date.now();

          // Stream the response
          for await (const chunk of anthropicStream) {
            if (chunk.type === 'content_block_delta' && chunk.delta.type === 'text_delta') {
              const text = chunk.delta.text;
              fullResponse += text;

              // Send progress updates every 500ms
              const now = Date.now();
              if (now - lastProgressUpdate > 500) {
                const progressData = {
                  type: 'progress',
                  received: fullResponse.length,
                  timestamp: new Date().toISOString()
                };
                controller.enqueue(
                  new TextEncoder().encode(`data: ${JSON.stringify(progressData)}\n\n`)
                );
                lastProgressUpdate = now;
              }
            }
          }

          console.log('[TOPICS API STREAM] Received complete response:', fullResponse.length, 'characters');

          // Parse the complete response
          let cleanText = fullResponse.trim();
          cleanText = cleanText.replace(/```json\n?/g, '');
          cleanText = cleanText.replace(/```\n?/g, '');
          cleanText = cleanText.trim();

          let parsedResponse;
          try {
            parsedResponse = JSON.parse(cleanText);
            console.log('[TOPICS API STREAM] Successfully parsed:', parsedResponse.topics?.length, 'topics');
          } catch (parseError) {
            console.error('[TOPICS API STREAM] JSON parse error:', parseError);
            console.error('[TOPICS API STREAM] Response length:', cleanText.length);
            
            const errorData = {
              type: 'error',
              error: 'Failed to parse AI response',
              details: parseError instanceof Error ? parseError.message : 'Parse error',
              responseLength: cleanText.length
            };
            controller.enqueue(
              new TextEncoder().encode(`data: ${JSON.stringify(errorData)}\n\n`)
            );
            controller.close();
            return;
          }

          // Validate structure
          if (!parsedResponse.topics || !Array.isArray(parsedResponse.topics)) {
            const errorData = {
              type: 'error',
              error: 'Invalid response structure',
              details: 'Response missing topics array'
            };
            controller.enqueue(
              new TextEncoder().encode(`data: ${JSON.stringify(errorData)}\n\n`)
            );
            controller.close();
            return;
          }

          // Send complete data
          const completeData = {
            type: 'complete',
            success: true,
            topics: parsedResponse.topics,
            metadata: {
              generated: new Date().toISOString(),
              count: parsedResponse.topics.length,
              month: body.month,
              regional: {
                location: body.regional.location,
                countryCode: body.regional.countryCode,
                language: body.regional.language,
              },
            },
          };

          controller.enqueue(
            new TextEncoder().encode(`data: ${JSON.stringify(completeData)}\n\n`)
          );
          
          console.log('[TOPICS API STREAM] Stream completed successfully');
          controller.close();

        } catch (error) {
          console.error('[TOPICS API STREAM] Error:', error);
          
          const errorData = {
            type: 'error',
            error: error instanceof Error ? error.message : 'Unknown error',
            errorType: error?.constructor?.name
          };
          
          controller.enqueue(
            new TextEncoder().encode(`data: ${JSON.stringify(errorData)}\n\n`)
          );
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('[TOPICS API STREAM] Request error:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown' },
      { status: 500 }
    );
  }
}

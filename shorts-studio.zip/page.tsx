'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Navigation from '../../../components/Navigation'

// Localization dictionary for British vs American English
const getLocalizedToneLabel = (tone: string, language: string) => {
  const isBritish = language?.includes('British') || language?.includes('UK')
  
  const labels: Record<string, { british: string; american: string }> = {
    emotional: { british: 'Emotional', american: 'Emotional' },
    calming: { british: 'Calming', american: 'Calming' },
    storytelling: { british: 'Storytelling', american: 'Storytelling' },
    educational: { british: 'Educational', american: 'Educational' },
    humor: { british: 'Humour', american: 'Humor' },
    humour: { british: 'Humour', american: 'Humor' },
    // Add more tone labels as needed
    inspirational: { british: 'Inspirational', american: 'Inspirational' },
    motivational: { british: 'Motivational', american: 'Motivational' },
    conversational: { british: 'Conversational', american: 'Conversational' },
  }
  
  const toneLower = tone.toLowerCase()
  if (labels[toneLower]) {
    return isBritish ? labels[toneLower].british : labels[toneLower].american
  }
  
  // Fallback: capitalize first letter
  return tone.charAt(0).toUpperCase() + tone.slice(1)
}

export default function NewProjectPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState(false)
  const [progress, setProgress] = useState<string>('')
  const [generatedTopics, setGeneratedTopics] = useState<any[]>([])
  const [profile, setProfile] = useState<any>(null)
  const [regional, setRegional] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  
  // Form state
  const [projectName, setProjectName] = useState('')
  const [month, setMonth] = useState('')
  const [videosPerDay, setVideosPerDay] = useState(1)
  const [bufferVideos, setBufferVideos] = useState(3)
  const [productionMode, setProductionMode] = useState<'traditional' | 'ai-voice' | 'fully-ai'>('traditional')
  const [toneMix, setToneMix] = useState({
    emotional: 30,
    calming: 25,
    storytelling: 20,
    educational: 15,
    humor: 10,
  })

  // Load profile and regional data
  useEffect(() => {
    try {
      const profileData = localStorage.getItem('userProfile')
      const regionalData = localStorage.getItem('regionalSettings')
      
      if (!profileData) {
        router.push('/dashboard')
        return
      }
      
      const parsedProfile = JSON.parse(profileData)
      setProfile(parsedProfile)
      
      if (regionalData) {
        const parsedRegional = JSON.parse(regionalData)
        setRegional(parsedRegional)
      } else {
        // Determine default language from profile
        const language = parsedProfile.languageVariant || 
                        (parsedProfile.targetAudience === 'United Kingdom' ? 'British English' : 
                         parsedProfile.country === 'United Kingdom' ? 'British English' : 'American English')
        
        const defaultRegional = {
          location: parsedProfile.targetAudience || parsedProfile.country || 'United Kingdom',
          countryCode: parsedProfile.country === 'United Kingdom' ? 'GB' : 'US',
          hemisphere: 'Northern',
          timezone: parsedProfile.country === 'United Kingdom' ? 'Europe/London' : 'America/New_York',
          language: language,
          holidays: []
        }
        setRegional(defaultRegional)
        localStorage.setItem('regionalSettings', JSON.stringify(defaultRegional))
      }
      
      setLoading(false)
    } catch (err) {
      console.error('Error loading data:', err)
      setError('Failed to load profile data')
      setLoading(false)
    }
  }, [router])

  const daysInMonth = month ? new Date(new Date(month).getFullYear(), new Date(month).getMonth() + 1, 0).getDate() : 30
  const totalVideos = (daysInMonth * videosPerDay) + bufferVideos

  const handleGenerateTopics = async () => {
    console.log('🎬 Starting streaming topic generation...')
    
    if (!profile || !regional) {
      setError('Profile or regional settings not loaded')
      return
    }

    if (!projectName || !month) {
      setError('Please fill in project name and month')
      return
    }

    setGenerating(true)
    setError(null)
    setProgress('Connecting to AI...')
    setGeneratedTopics([])

    try {
      const requestBody = {
        projectName,
        month,
        videosNeeded: totalVideos,
        toneMix,
        profile: {
          niche: profile.niche || '',
          uniqueAngle: profile.uniqueAngle || '',
          signatureTone: profile.signatureTone || {
            primary: 'storytelling',
            secondary: 'educational',
            accent: 'humor'
          },
          wontCover: profile.wontCover || [],
          catchphrases: profile.catchphrases || [],
          targetAudience: profile.targetAudience || profile.country,
          languageVariant: profile.languageVariant || regional.language
        },
        regional: {
          location: regional.location,
          countryCode: regional.countryCode,
          hemisphere: regional.hemisphere,
          timezone: regional.timezone,
          language: regional.language,
          holidays: regional.holidays || []
        },
        productionMode
      }

      console.log('📤 Sending request to generate topics:', requestBody)

      // Try the streaming endpoint first, fall back to non-streaming
      let endpoint = '/api/topics/generate-stream'
      let response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      })

      // If 404, try the non-streaming endpoint
      if (response.status === 404) {
        console.log('⚠️ Streaming endpoint not found, trying /api/topics/generate')
        endpoint = '/api/topics/generate'
        response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        })
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Failed to generate topics' }))
        throw new Error(errorData.error || `Server error: ${response.status}`)
      }

      // Check if response is streaming (Server-Sent Events) or regular JSON
      const contentType = response.headers.get('content-type')
      const isStreaming = contentType?.includes('text/event-stream')

      if (isStreaming) {
        // Handle streaming response
        const reader = response.body?.getReader()
        if (!reader) {
          throw new Error('No response stream available')
        }

        const decoder = new TextDecoder()
        let buffer = ''
        
        while (true) {
          const { done, value } = await reader.read()
          
          if (done) {
            console.log('✅ Stream completed')
            break
          }

          buffer += decoder.decode(value, { stream: true })
          const lines = buffer.split('\n\n')
          buffer = lines.pop() || ''

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.slice(6))
                
                if (data.type === 'progress') {
                  setProgress(data.message)
                } else if (data.type === 'topic') {
                  setGeneratedTopics(prev => [...prev, data.topic])
                } else if (data.type === 'complete') {
                  setProgress('Saving topics to project...')
                  
                  // Save the topics to project
                  const topics = data.topics || []
                  console.log('💾 Saving', topics.length, 'topics to project')
                  
                  // Create new project with topics
                  const newProject = {
                    id: Date.now().toString(),
                    name: projectName,
                    month: month,
                    topics: topics,
                    scripts: [],
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString(),
                    videosPerDay: videosPerDay,
                    bufferVideos: bufferVideos,
                    productionMode: productionMode,
                    toneMix: toneMix,
                  }
                  
                  // Save to localStorage
                  try {
                    const existingProjects = JSON.parse(localStorage.getItem('projects') || '[]')
                    existingProjects.push(newProject)
                    localStorage.setItem('projects', JSON.stringify(existingProjects))
                    console.log('✅ Project saved to localStorage')
                    
                    setProgress('Complete! Redirecting to dashboard...')
                    
                    setTimeout(() => {
                      router.push('/dashboard')
                    }, 1500)
                  } catch (saveError) {
                    console.error('❌ Error saving project:', saveError)
                    setError('Topics generated but failed to save project')
                  }
                  
                } else if (data.type === 'error') {
                  throw new Error(data.error || 'Unknown error')
                }
              } catch (parseError) {
                console.error('Failed to parse SSE data:', parseError)
              }
            }
          }
        }
      } else {
        // Handle regular JSON response
        const data = await response.json()
        
        if (data.topics && Array.isArray(data.topics)) {
          setProgress('Saving topics to project...')
          setGeneratedTopics(data.topics)
          console.log('💾 Saving', data.topics.length, 'topics to project')
          
          // Create new project with topics
          const newProject = {
            id: Date.now().toString(),
            name: projectName,
            month: month,
            topics: data.topics,
            scripts: [],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            videosPerDay: videosPerDay,
            bufferVideos: bufferVideos,
            productionMode: productionMode,
            toneMix: toneMix,
          }
          
          // Save to localStorage
          try {
            const existingProjects = JSON.parse(localStorage.getItem('projects') || '[]')
            existingProjects.push(newProject)
            localStorage.setItem('projects', JSON.stringify(existingProjects))
            console.log('✅ Project saved to localStorage')
            
            setProgress('Complete! Redirecting to dashboard...')
            
            setTimeout(() => {
              router.push('/dashboard')
            }, 1500)
          } catch (saveError) {
            console.error('❌ Error saving project:', saveError)
            setError('Topics generated but failed to save project')
          }
        } else {
          throw new Error('Invalid response format from API')
        }
      }
      
    } catch (err) {
      console.error('❌ Error generating topics:', err)
      setError(err instanceof Error ? err.message : 'Failed to generate topics')
      setProgress('')
    } finally {
      setGenerating(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="text-center">Loading...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <button
            onClick={() => router.push('/dashboard')}
            className="text-blue-600 hover:text-blue-700 mb-4"
          >
            ← Back to Dashboard
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Create New Project</h1>
          <p className="text-gray-600 mt-2">
            Plan your content for the month with AI-generated topics
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">
            {error}
          </div>
        )}

        {progress && (
          <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded mb-6 flex items-center">
            <svg className="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            {progress}
          </div>
        )}

        {generatedTopics.length > 0 && (
          <div className="bg-green-50 border border-green-200 rounded mb-6 p-4">
            <h3 className="font-semibold text-green-900 mb-2">
              ✅ Generated {generatedTopics.length} Topics!
            </h3>
            <div className="text-sm text-green-700 space-y-1 max-h-48 overflow-y-auto">
              {generatedTopics.slice(0, 5).map((topic, i) => (
                <div key={i}>• {topic.title}</div>
              ))}
              {generatedTopics.length > 5 && (
                <div className="text-green-600">...and {generatedTopics.length - 5} more</div>
              )}
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
          {/* Project Basics */}
          <div>
            <h2 className="text-xl font-semibold mb-4">1. Project Basics</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Project Name
                </label>
                <input
                  type="text"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="e.g., December 2025"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  disabled={generating}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Month
                </label>
                <input
                  type="month"
                  value={month}
                  onChange={(e) => setMonth(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  disabled={generating}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Videos per Day
                  </label>
                  <select
                    value={videosPerDay}
                    onChange={(e) => setVideosPerDay(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    disabled={generating}
                  >
                    <option value={1}>1 per day</option>
                    <option value={2}>2 per day</option>
                    <option value={3}>3 per day</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Buffer Videos
                  </label>
                  <input
                    type="number"
                    value={bufferVideos}
                    onChange={(e) => setBufferVideos(Number(e.target.value))}
                    min={0}
                    max={10}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    disabled={generating}
                  />
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                <p className="text-sm text-blue-900 font-medium">
                  Total videos needed: <span className="font-bold">{totalVideos}</span>
                </p>
                <p className="text-xs text-blue-700 mt-1">
                  ({daysInMonth} days × {videosPerDay} {videosPerDay === 1 ? 'video' : 'videos'} + {bufferVideos} buffer)
                </p>
              </div>
            </div>
          </div>

          {/* Production Mode */}
          <div>
            <h2 className="text-xl font-semibold mb-4">2. Production Mode</h2>
            
            <div className="space-y-3">
              <label className="flex items-start space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  name="productionMode"
                  value="traditional"
                  checked={productionMode === 'traditional'}
                  onChange={(e) => setProductionMode(e.target.value as any)}
                  className="mt-1"
                  disabled={generating}
                />
                <div>
                  <div className="font-medium">Traditional Filming</div>
                  <div className="text-sm text-gray-600">
                    You film yourself speaking directly to camera
                  </div>
                </div>
              </label>

              <label className="flex items-start space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  name="productionMode"
                  value="ai-voice"
                  checked={productionMode === 'ai-voice'}
                  onChange={(e) => setProductionMode(e.target.value as any)}
                  className="mt-1"
                  disabled={generating}
                />
                <div>
                  <div className="font-medium">AI Voice + Stock Footage</div>
                  <div className="text-sm text-gray-600">
                    AI voiceover with stock footage and B-roll
                  </div>
                </div>
              </label>

              <label className="flex items-start space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                <input
                  type="radio"
                  name="productionMode"
                  value="fully-ai"
                  checked={productionMode === 'fully-ai'}
                  onChange={(e) => setProductionMode(e.target.value as any)}
                  className="mt-1"
                  disabled={generating}
                />
                <div>
                  <div className="font-medium">Fully AI-Generated</div>
                  <div className="text-sm text-gray-600">
                    AI-generated video, voice, and visuals
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* Tone Mix - WITH LOCALIZATION */}
          <div>
            <h2 className="text-xl font-semibold mb-4">3. Tone Mix</h2>
            
            <div className="space-y-4">
              {Object.entries(toneMix).map(([tone, value]) => (
                <div key={tone}>
                  <div className="flex justify-between mb-1">
                    <label className="text-sm font-medium text-gray-700">
                      {getLocalizedToneLabel(tone, regional?.language || profile?.languageVariant || '')}
                    </label>
                    <span className="text-sm text-gray-600">{value}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={value}
                    onChange={(e) => setToneMix({
                      ...toneMix,
                      [tone]: Number(e.target.value)
                    })}
                    className="w-full"
                    disabled={generating}
                  />
                </div>
              ))}
              
              <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
                Total: {Object.values(toneMix).reduce((a, b) => a + b, 0)}%
                {Object.values(toneMix).reduce((a, b) => a + b, 0) !== 100 && (
                  <span className="text-amber-600 ml-2">
                    (Note: Should total 100% for best results)
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Regional Info */}
          {regional && (
            <div className="bg-gray-50 border border-gray-200 rounded-md p-4">
              <h3 className="font-medium text-gray-900 mb-2">Regional Settings</h3>
              <div className="text-sm text-gray-600 space-y-1">
                <div>📍 Location: {regional.location}</div>
                <div>🌍 Country: {regional.countryCode}</div>
                <div>💬 Language: {regional.language}</div>
                <div>🕐 Timezone: {regional.timezone}</div>
              </div>
            </div>
          )}

          {/* Generate Button */}
          <div className="pt-4 border-t">
            <button
              onClick={handleGenerateTopics}
              disabled={generating || !projectName || !month}
              className={`w-full py-3 px-4 rounded-md font-medium transition-colors ${
                generating || !projectName || !month
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {generating ? 'Generating Topics...' : 'Generate Topics with AI'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
